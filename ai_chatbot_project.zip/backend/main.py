from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from db import get_db
from chatbot import get_response

app = FastAPI()

@app.get("/query")
def query_chatbot(user_input: str, db: Session = Depends(get_db)):
    response = get_response(user_input, db)
    return {"response": response}
