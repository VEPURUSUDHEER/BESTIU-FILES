INSERT INTO suppliers (name, contact_info, categories) VALUES
('TechSupply', 'tech@example.com', 'Electronics'),
('HomeGoods', 'home@example.com', 'Furniture');

INSERT INTO products (name, brand, price, category, description, supplier_id) VALUES
('Laptop X', 'BrandA', 999.99, 'Electronics', 'High performance laptop', 1),
('Sofa Set', 'BrandB', 599.99, 'Furniture', 'Comfortable living room sofa', 2);
