import React, { useState } from 'react';
import axios from 'axios';

const Chatbot = () => {
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState([]);

  const sendMessage = async () => {
    if (!query) return;
    const response = await axios.get(`/query?user_input=${query}`);
    setMessages([...messages, { user: query, bot: response.data.response }]);
    setQuery('');
  };

  return (
    <div>
      {messages.map((msg, index) => (
        <div key={index}>
          <p><strong>You:</strong> {msg.user}</p>
          <p><strong>Bot:</strong> {msg.bot}</p>
        </div>
      ))}
      <input value={query} onChange={(e) => setQuery(e.target.value)} />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
};

export default Chatbot;
